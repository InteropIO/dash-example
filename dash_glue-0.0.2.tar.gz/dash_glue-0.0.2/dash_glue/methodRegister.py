# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class methodRegister(Component):
    """A methodRegister component.


Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- loading_state (dict with strings as keys and values of type ; optional): Dash-assigned prop that tells whether the component is currently loading.
- definition (dict; optional): Method's name or an object holding the method name, signature and other properties of the method.
- methodResponseTimeoutMs (number; default 30000): Timeout to wait for the handler to reply. Set this prop to configure how much time should the component wait for a response from Dash backend.
Default 30000 ms.
- error (dict; optional): An error if method registration fails.
- returns (boolean; default False): An option whether the method is void or returns a result.
Default false.
- result (dict; optional): result has the following type: dict containing keys 'invocationId', 'invocationResult', 'error'.
Those keys have the following types:
  - invocationId (string; optional): An ID to correlate a method invocation to its result.
  - invocationResult (dict; optional): The actual results from a method invocation.
  - error (dict; optional): An error if method invocation should fail.
- call (dict; optional): Notifies when the registered method is invoked. call has the following type: dict containing keys 'invocationId', 'args', 'caller'.
Those keys have the following types:
  - invocationId (string; optional): An ID to correlate a method invocation to its result.
  - args (dict; optional): Invocation arguments.
  - caller (dict; optional)"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, loading_state=Component.UNDEFINED, definition=Component.UNDEFINED, methodResponseTimeoutMs=Component.UNDEFINED, error=Component.UNDEFINED, returns=Component.UNDEFINED, result=Component.UNDEFINED, call=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'loading_state', 'definition', 'methodResponseTimeoutMs', 'error', 'returns', 'result', 'call']
        self._type = 'methodRegister'
        self._namespace = 'dash_glue'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'loading_state', 'definition', 'methodResponseTimeoutMs', 'error', 'returns', 'result', 'call']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(methodRegister, self).__init__(**args)
