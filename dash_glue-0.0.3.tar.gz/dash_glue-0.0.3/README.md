# What is this

The repository includes Dash components for Glue42 initialization and two way message exchange for channels, contexts, registering methods and invoking methods. A simple demo which runs both in Glue42 Core and Glue42 Enterprise is also available.

## Quickstart

1. Setup the Python environment (more detailed instructions of how to setup Dash can be found here - https://dash.plotly.com/installation )
```sh
python -m virtualenv venv

# Unix
source venv/bin/activate
# Windows
.\venv\Scripts\activate.bat

pip install -r requirements.txt
```

2. Install JavaScript dependencies.

```
npm install
```

3. To build the library (this will build the JS and Python library. R build is disabled due to https://github.com/plotly/dash/issues/1050 )

```
npm run build
```

4. To pack the library

```
npm run pack
```

This command will create a tarball in `/dist`.

## Running the applications

Install the `concurrently` package that is used by the startup script globally.

```
npm i -g concurrently
```

Start the Flask servers hosting the applications

```
npm start
```

or if running on Windows

```
npm run start_win
```

### Glue42 Core 

Open [http://localhost:4242](http://localhost:4242) in your browser.

### Glue42 Enterprise

To run the two applications in a Glue42 Enterprise environment, make sure to have Glue42 3.9 (or later) installed. Then, add the following entry to your application configuration ([read this document](https://docs.glue42.com/developers/configuration/application/index.html#application_configuration) if you have not done it before):

```json
[
    {
        "title": "Dash App 1",
        "type": "window",
        "name": "dash1",
        "hidden": false,
        "details": {
            "url": "http://0.0.0.0:8050/",
            "top": 25,
            "left": 800,
            "height": 400,
            "width": 400
        }
    },
    {
        "title": "Dash App 2",
        "type": "window",
        "name": "dash2",
        "hidden": false,
        "details": {
            "url": "http://0.0.0.0:8051/",
            "top": 25,
            "left": 0,
            "height": 400,
            "width": 400
        }
    }
]
```

Afterwards, you can launch the two applications (Dash App 1 and Dash App 2) from the Glue42 toolbar.

