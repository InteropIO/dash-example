# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class context(Component):
    """A context component.


Keyword arguments:
- id (optional): The ID of this component, used to identify dash components in callbacks.
The ID needs to be unique across all of the components in an app.
- setProps (optional): Dash-assigned callback that should be called to report property changes to Dash, to make them available for callbacks.
- current (dict with strings as keys and values of type ; optional): Holds the latest context update.
- update (dict; optional): Property for updating the shared context.
An object that will be merged with the existing context object.
- set (dict; optional): Property for setting a new context value.
An object will replace the context value completely."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, current=Component.UNDEFINED, update=Component.UNDEFINED, set=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'setProps', 'current', 'update', 'set']
        self._type = 'context'
        self._namespace = 'dash_glue'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'setProps', 'current', 'update', 'set']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(context, self).__init__(**args)
