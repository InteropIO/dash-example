# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class methodInvoke(Component):
    """A methodInvoke component.


Keyword arguments:
- id (optional): The ID of this component, used to identify dash components in callbacks.
The ID needs to be unique across all of the components in an app.
- setProps (optional): Dash-assigned callback that should be called to report property changes to Dash, to make them available for callbacks.
- result (dict; optional): Property that returns a result or an error from an invocation. result has the following type: dict containing keys 'invocationId', 'invocationResult', 'error'.
Those keys have the following types:
  - invocationId (string; optional): An ID to correlate a method invocation to its result.
  - invocationResult (dict; optional): The actual result from a method invocation. If the invocation fails then a null value is set.
  - error (dict; optional): An error if method invocation fails. Has a null value unless the invocation failed.
- call (dict; optional): Property for invoking an interop method. call has the following type: dict containing keys 'invocationId', 'definition', 'argumentObj', 'target', 'options'.
Those keys have the following types:
  - invocationId (string; optional): An ID to correlate a method invocation to its result.
  - definition (required): Method's name or an object holding the method name, signature and other properties of the method.
  - argumentObj (dict; optional): Invocation arguments.
  - target (string | dict | list of dicts; optional): Specifying target server.
  - options (dict; optional)"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, result=Component.UNDEFINED, call=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'setProps', 'result', 'call']
        self._type = 'methodInvoke'
        self._namespace = 'dash_glue'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'setProps', 'result', 'call']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(methodInvoke, self).__init__(**args)
