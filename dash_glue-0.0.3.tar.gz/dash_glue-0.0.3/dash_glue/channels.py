# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class channels(Component):
    """A channels component.


Keyword arguments:
- id (string; optional): The ID used to identify this component in Dash callbacks.
- incoming (dict; optional): Holds the current channel info and its data. incoming has the following type: dict containing keys 'channel', 'data'.
Those keys have the following types:
  - channel (optional): Current channel context.
  - data (boolean | number | string | dict | list; optional): Current channel data.
- outgoing (dict; optional): Property for publishing new data to the current channel.
- change (dict; optional): Property for navigating through channels. change has the following type: dict containing keys 'action', 'channelName'.
Those keys have the following types:
  - action (a value equal to: 'join', 'leave'; required)
  - channelName (string; optional)
- channelsInfo (list; optional): A list of all channel contexts."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, incoming=Component.UNDEFINED, outgoing=Component.UNDEFINED, change=Component.UNDEFINED, channelsInfo=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'incoming', 'outgoing', 'change', 'channelsInfo']
        self._type = 'channels'
        self._namespace = 'dash_glue'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'incoming', 'outgoing', 'change', 'channelsInfo']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(channels, self).__init__(**args)
