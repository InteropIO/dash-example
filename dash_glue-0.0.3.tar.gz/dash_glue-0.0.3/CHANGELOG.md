# Changelog

## [0.0.3] - 2020-08-20

### Changed

- Improved error handing in methodInvoke and methodRegister components.
- In methodRegister `definition` property type accepts either a string or an object.
- Added more reference comments to components properties .

## [0.0.2] - 2020-07-31

### Added

-   Leaving the current channel.
-   Joining a channel.
-   Getting the list of channels.

### Changed

-   Raising notifications through Glue42 Notifications API.

## [0.0.1] - 2020-07-29

### Added

-   Invoking interop methods.
-   Registering interop methods.
-   Window opening.
-   GNS notification raising.
-   Glue42 Contexts - subscribing and updating a shared context.
-   Glue42 Channels - subscribing to a channel and publishing data to the current channel.
